"""Original WolfShield polygon artwork, rasterized with Pillow. No external assets."""
from pathlib import Path
from PIL import Image, ImageDraw
root=Path(__file__).resolve().parents[1]/'public'/'icons'
root.mkdir(parents=True,exist_ok=True)
shapes=[('#248FC5',[(12,8),(33,26),(50,21),(67,26),(88,8),(94,48),(79,77),(50,96),(21,77),(6,48)]),('#60CBF5',[(12,8),(33,26),(24,47),(6,48)]),('#60CBF5',[(88,8),(67,26),(76,47),(94,48)]),('#102234',[(33,26),(50,37),(67,26),(76,47),(66,63),(50,57),(34,63),(24,47)]),('#8ADFFF',[(19,55),(34,59),(40,68),(25,64)]),('#8ADFFF',[(81,55),(66,59),(60,68),(75,64)]),('#1376AA',[(21,77),(40,68),(50,81),(60,68),(79,77),(50,96)]),('#65D1FC',[(40,68),(50,64),(60,68),(50,81)]),('#102234',[(43,66),(57,66),(50,73)]),('#8ADFFF',[(50,81),(62,77),(50,91),(38,77)])]
svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 104" role="img" aria-label="WolfShield">'+''.join(f'<polygon fill="{color}" points="'+ ' '.join(f'{x},{y}' for x,y in points)+'"/>' for color,points in shapes)+'</svg>'
(root/'wolf.svg').write_text(svg,encoding='utf-8')
for size in (16,32,48,64,128,256,512):
    im=Image.new('RGBA',(size*4,size*4),(0,0,0,0));d=ImageDraw.Draw(im)
    for color,points in shapes:d.polygon([(x/104*size*4+size*.08,y/104*size*4) for x,y in points],fill=color)
    im.resize((size,size),Image.Resampling.LANCZOS).save(root/f'icon{size}.png')
print('Original SVG and seven PNG sizes generated')
